1) GitHub এ নতুন repo বানান (নাম যা খুশি), এই zip এর সব file (.github ফোল্ডারসহ) upload করুন।
2) Repo > Settings > Pages > Source = "GitHub Actions" সেট করুন।
3) Actions ট্যাবে "Build APK" শেষ হলে Releases থেকে MyDrive.apk নামান।
4) Firebase: Authentication > Email/Password চালু করুন, Authorized domains এ <username>.github.io যোগ করুন, firebase-rules.txt এর rules বসান।
